import TeamSection from "@/components/team-section";

export default function Team() {
  return (
    <div className="min-h-screen">
      <TeamSection />
    </div>
  );
}


